package school.sptech;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Jitter {

    private static final Pattern TEMPO =
            Pattern.compile("(?:time|tempo)\\s*[=<]\\s*([\\d.,]+)\\s*ms", Pattern.CASE_INSENSITIVE);

    public static List<Double> obterLatencias(String host, int count) {
        boolean windows = System.getProperty("os.name").toLowerCase().contains("win");
        String param = windows ? "-n" : "-c";
        List<Double> latencias = new ArrayList<>();

        try {
            Process p = new ProcessBuilder("ping", param, String.valueOf(count), host)
                    .redirectErrorStream(true)
                    .start();

            try (BufferedReader leitor = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String linha;
                while ((linha = leitor.readLine()) != null) {
                    Matcher m = TEMPO.matcher(linha);
                    if (m.find()) {
                        latencias.add(Double.parseDouble(m.group(1).replace(',', '.')));
                    }
                }
            }
            p.waitFor();
        } catch (Exception e) {
            System.out.println("Erro ao executar o ping: " + e.getMessage());
        }
        return latencias;
    }

    public static double calcularJitter(List<Double> latencias) {
        if (latencias.size() < 2) {
            return 0.0;
        }
        double soma = 0;
        for (int i = 1; i < latencias.size(); i++) {
            soma += Math.abs(latencias.get(i) - latencias.get(i - 1));
        }
        return soma / (latencias.size() - 1);
    }

    public static double media(List<Double> valores) {
        return valores.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
    }

    public static void main(String[] args) throws InterruptedException {
        String ipAlvo = "8.8.8.8";
        System.out.println("Monitorando latência de " + ipAlvo + "...");

        for (int i = 0; i < 5; i++) {
            List<Double> tempos = obterLatencias(ipAlvo, 10);
            if (!tempos.isEmpty()) {
                System.out.printf("Latência Média: %.2f ms | Jitter: %.2f ms%n",
                        media(tempos), calcularJitter(tempos));
            } else {
                System.out.println("Falha ao contatar o dispositivo (possível perda total de pacotes).");
            }
            Thread.sleep(1000);
        }
    }
}