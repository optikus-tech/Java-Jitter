package school.sptech;

import com.github.britooo.looca.api.core.Looca;
import com.github.britooo.looca.api.group.rede.RedeInterface;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import java.util.Map;
import java.net.InetAddress;

public class Main {
    public static void main(String[] args) throws Exception{
        ConexaoBD conexaoBD = new ConexaoBD();

        try(Connection conexao = conexaoBD.getBasicDataSource().getConnection()){
            if (conexao.isValid(2)){
                System.out.println("Conexão Realizada com Sucesso!!!");
            }
        }catch (SQLException e){
            System.out.println("Não foi possível conectar ao banco "+ e.getMessage());
            return;
        }

        JdbcTemplate jdbcTemplate = new ConexaoBD().getJdbcTemplate();

        Looca looca = new Looca();
        String ipAlvo = "www.baidu.com";
        String hostname = InetAddress.getLocalHost().getHostName();
        System.out.println("HostName: " + hostname);
        int idComponente = jdbcTemplate.queryForObject(
                """
                SELECT c.id
                FROM componente c
                JOIN servidor s ON s.id = c.id_servidor
                WHERE s.hostname = ? AND c.nome = ?
                """,
                Integer.class, hostname, "Segundos Perdidos"
        );
        SimpleJdbcInsert insertCaptura = new SimpleJdbcInsert(jdbcTemplate)
            .withTableName("captura")
                .usingGeneratedKeyColumns("id")
                .usingColumns("valor", "id_componente");

        String sqlAlerta = """
                INSERT INTO alerta(nivel, id_captura, id_parametro)
                SELECT ?, ?, id FROM parametro_limite
                WHERE id_componente = ? AND criticidade = ?""";


        final int FPS = 28;
        double bitsPorSegundo = 6_000_000;
        final double bytesPorPacote = 1400;
        final int TOTAL_PINGS = 10;
        double duracaoJanela = 60.0;

        double bytesPorFrame = bitsPorSegundo / 8 / FPS;
        int pacotesPorFrame = (int) Math.ceil(bytesPorFrame / bytesPorPacote);

        double totalSegundosPerdidos = 0.0;
        double segundosPerdidosJanela = 0.0;
        double tempoJanela = 0.0;

        while(true) {
            long inicio = System.currentTimeMillis();
            List<RedeInterface> interfaces = looca.getRede().getGrupoDeInterfaces().getInterfaces();

            long recebidos = interfaces.stream()
                    .mapToLong(RedeInterface::getBytesRecebidos)
                    .max()
                    .orElse(0);

            long enviados = interfaces.stream()
                    .mapToLong(RedeInterface::getBytesEnviados)
                    .max()
                    .orElse(0);

            List<Double> tempos = Jitter.obterLatencias(ipAlvo, 10);

            int pacotesPerdidos = TOTAL_PINGS - tempos.size();
            double taxaPerdaPacotes = (double) pacotesPerdidos / TOTAL_PINGS;
            double perdaPercentualPacotes = taxaPerdaPacotes * 100;

            double janelaSegundos = (System.currentTimeMillis() - inicio) / 1000.0;

            double perdaFrame = 1 - Math.pow(1 - taxaPerdaPacotes, pacotesPorFrame);
            double segundosPerdidos = janelaSegundos * perdaFrame;
            totalSegundosPerdidos += segundosPerdidos;
            segundosPerdidosJanela += segundosPerdidos;
            tempoJanela += janelaSegundos + 1.0;

            if (!tempos.isEmpty()) {
                System.out.printf("Recebidos: %d | Enviados: %d | Latência: %.2f ms | Jitter: %.2f ms%n",
                        recebidos, enviados, Jitter.media(tempos), Jitter.calcularJitter(tempos));
            } else {
                System.out.printf("Recebidos: %d | Enviados: %d | Latência e Jitter: falha ao contatar o host%n",
                        recebidos, enviados);
            }

            if (Jitter.media(tempos) <= 150){
                System.out.printf("Latência Ideal!!! (%.2f ms)%n", Jitter.media(tempos));
            }else if(Jitter.media(tempos) > 150 && Jitter.media(tempos) <= 300){
                System.out.printf("Latência em Alerta!! (%.2f ms)%n", Jitter.media(tempos));
            }else if(Jitter.media(tempos) > 300){
                System.out.printf("Latência Crítica!!! (%.2f ms)%n", Jitter.media(tempos));
            }

            if (Jitter.calcularJitter(tempos) == 0.0){
                System.out.printf("Jitter Ideal!! (%.2f ms)%n", Jitter.calcularJitter(tempos));
            }else if(Jitter.calcularJitter(tempos) <= 10){
                System.out.printf("Jitter Excelente!! (%.2f ms)%n", Jitter.calcularJitter(tempos));
            }else if(Jitter.calcularJitter(tempos) <= 30){
                System.out.printf("Jitter Aceitável!! (%.2f ms)%n", Jitter.calcularJitter(tempos));
            }else if(Jitter.calcularJitter(tempos) > 30){
                System.out.printf("Jitter Crítico (%.2f ms)%n", Jitter.calcularJitter(tempos));
            }

            if (perdaPercentualPacotes <= 1){
                System.out.printf("Perda de Pacotes Aceitável!!! (%d de %d pacotes | %.1f%%)%n", pacotesPerdidos, TOTAL_PINGS,
                        perdaPercentualPacotes);
            }else{
                System.out.printf("Perda de Pacotes Prejudicial!!! (%d de %d pacotes | %.1f%%)%n", pacotesPerdidos, TOTAL_PINGS,
                        perdaPercentualPacotes);
            }

            if (tempoJanela >= duracaoJanela){
                long idCaptura = insertCaptura
                        .executeAndReturnKey(Map.of("valor", segundosPerdidosJanela, "id_componente", idComponente))
                        .longValue();
                String nivel;
                if (segundosPerdidosJanela <= 0.035){
                    System.out.printf("Perda de Segundos Baixa!!! (%.3f s em %.0f s)%n", segundosPerdidosJanela, tempoJanela);
                    nivel = "BAIXO";
                }else if(segundosPerdidosJanela <= 0.5){
                    System.out.printf("Perda de Segundos Média!!! (%.3f s em %.0f s)%n", segundosPerdidosJanela, tempoJanela);
                    nivel = "MEDIO";
                }else if(segundosPerdidosJanela <= 1){
                    System.out.printf("Perda de Segundos Alta!!! (%.3f s em %.0f s)%n", segundosPerdidosJanela, tempoJanela);
                    nivel = "ALTO";
                }else{
                    System.out.printf("Perda de Segundos Crítica!!! (%.3f s em %.0f s)%n", segundosPerdidosJanela, tempoJanela);
                    nivel = "CRITICO";
                }

                jdbcTemplate.update(sqlAlerta, nivel, idCaptura, idComponente, nivel);
                segundosPerdidosJanela = 0;
                tempoJanela = 0;
            }

            Thread.sleep(1000);
            jdbcTemplate.update("INSERT INTO captura(valor, id_componente) VALUES(?, ?)", segundosPerdidos, idComponente);
            System.out.println("Segundos Perdidos Inseridos no Banco!!!");

        }
    }
}